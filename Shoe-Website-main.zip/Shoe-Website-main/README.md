# Shoe-Website
Shoes E-Commerce Webiste
This is a static shoes website which is build up using Django. It has options like we can add shoes to cart and proceed to checkout and further payment option is yet to done.
This front-end of this website is not yet completed.
But, the backend posture is fully optimized and completed.

### **Here you can see the Screenshots**


![WhatsApp Image 2020-11-06 at 9 00 29 PM](https://user-images.githubusercontent.com/39701802/98393047-c51e5680-207e-11eb-8067-142851118e46.jpeg)


![WhatsApp Image 2020-11-06 at 9 01 37 PM](https://user-images.githubusercontent.com/39701802/98392931-986a3f00-207e-11eb-983a-18e9dd2c0c12.jpeg)
